import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PageGestionRendezVous extends StatelessWidget {
  const PageGestionRendezVous({super.key});

  @override
  Widget build(BuildContext context) {
    final String idMedecin = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Rendez-vous Confirmés",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('demandes')
            .where('medecinId', isEqualTo: idMedecin)
            .where('status', isEqualTo: 'Acceptée')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text("Erreur de chargement des rendez-vous"));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("Aucun rendez-vous confirmé"));
          }

          final rendezVous = snapshot.data!.docs;

          return ListView.builder(
            itemCount: rendezVous.length,
            itemBuilder: (context, index) {
              final rdv = rendezVous[index].data() as Map<String, dynamic>;
              if (!rdv.containsKey('date') || !rdv.containsKey('patientId')) {
                return const ListTile(
                  title: Text("Données incomplètes"),
                  subtitle: Text("Certains champs sont manquants pour ce rendez-vous."),
                );
              }

              final dateHeure = (rdv['date'] as Timestamp?)?.toDate();
              final String patientId = rdv['patientId'];

              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance.collection('users').doc(patientId).get(),
                builder: (context, userSnapshot) {
                  if (userSnapshot.connectionState == ConnectionState.waiting) {
                    return const ListTile(
                      title: Text("Chargement des informations du patient..."),
                    );
                  }
                  if (userSnapshot.hasError ||
                      !userSnapshot.hasData ||
                      !userSnapshot.data!.exists) {
                    return const ListTile(
                      title: Text("Erreur de chargement du patient"),
                      subtitle: Text("Impossible d'afficher les informations du patient."),
                    );
                  }

                  final patientData = userSnapshot.data!.data() as Map<String, dynamic>;
                  final String nomPatient = patientData['name'] ?? 'Inconnu';
                  final String motif = rdv['motif'] ?? 'Aucun motif spécifié';

                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    margin: const EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      leading: const Icon(Icons.calendar_today, color: Color(0xFF54D3C2)),
                      title: Text("Patient : $nomPatient"),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (dateHeure != null)
                            Text(
                              "Date : ${dateHeure.day}/${dateHeure.month}/${dateHeure.year} - ${dateHeure.hour}:${dateHeure.minute}",
                            ),
                          Text("Motif : $motif"),
                        ],
                      ),
                      trailing: ElevatedButton(
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                  "Modification pour RDV du ${dateHeure?.day}/${dateHeure?.month}/${dateHeure?.year}"),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF64B5F6),
                        ),
                        child: const Text("Modifier"),
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
