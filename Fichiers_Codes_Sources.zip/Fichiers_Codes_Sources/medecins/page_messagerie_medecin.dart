import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PageMessagerieMedecin extends StatefulWidget {
  final String patientId;
  final String conversationId;
  final String medecinId;

  const PageMessagerieMedecin({
    super.key,
    required this.patientId,
    required this.conversationId,
    required this.medecinId,
  });

  @override
  State<PageMessagerieMedecin> createState() => _PageMessagerieMedecinState();
}

class _PageMessagerieMedecinState extends State<PageMessagerieMedecin> {
  final TextEditingController _controleurMessage = TextEditingController();
  String _nomPatient = ""; 

  @override
  void initState() {
    super.initState();
    _recupererNomPatient();
  }

 
  Future<void> _recupererNomPatient() async {
    try {
      final DocumentSnapshot patientSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.patientId)
          .get();

      if (patientSnapshot.exists) {
        setState(() {
          _nomPatient = patientSnapshot['name'] ?? "Inconnu";
        });
      } else {
        setState(() {
          _nomPatient = "Inconnu";
        });
      }
    } catch (e) {
      print("Erreur lors de la récupération du nom du patient : $e");
      setState(() {
        _nomPatient = "Erreur";
      });
    }
  }
 
  Future<void> _envoyerMessage() async {
    if (_controleurMessage.text.trim().isEmpty) return;

    final message = {
      'senderId': widget.medecinId,
      'receiverId': widget.patientId,
      'content': _controleurMessage.text.trim(),
      'timestamp': FieldValue.serverTimestamp(),
    };

    await FirebaseFirestore.instance
        .collection('conversations')
        .doc(widget.conversationId)
        .collection('messages')
        .add(message);

    _controleurMessage.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: Text("à :$_nomPatient",
         style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
         
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('conversations')
                  .doc(widget.conversationId)
                  .collection('messages')
                  .orderBy('timestamp', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return const Center(
                      child: Text("Erreur lors du chargement des messages"));
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Center(child: Text("Aucun message"));
                }

                final messages = snapshot.data!.docs;

                return ListView.builder(
                  reverse: true,
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index];
                    final estExpediteur =
                        message['senderId'] == widget.medecinId;

                    return Align(
                      alignment: estExpediteur
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(
                            vertical: 5, horizontal: 10),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color:
                              estExpediteur ? Colors.blue : Colors.grey[300],
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          message['content'],
                          style: TextStyle(
                            color: estExpediteur ? Colors.white : Colors.black,
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
         
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controleurMessage,
                    decoration: InputDecoration(
                      hintText: "Tapez votre message...",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                IconButton(
                  icon: const Icon(Icons.send, color: Color(0xFF54D3C2)),
                  onPressed: _envoyerMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}


