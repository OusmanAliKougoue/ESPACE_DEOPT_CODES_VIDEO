import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PageGestionDemandes extends StatelessWidget {
  const PageGestionDemandes({super.key});

  @override
  Widget build(BuildContext context) {
    final String idMedecin = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Listes de rendez-vous",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('demandes')
            .where('medecinId', isEqualTo: idMedecin)
            .where('status', isEqualTo: 'En attente')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text("Erreur de chargement des demandes"));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("Aucune demande de consultation"));
          }

          final demandes = snapshot.data!.docs;

          return ListView.builder(
            itemCount: demandes.length,
            itemBuilder: (context, index) {
              final demande = demandes[index];
              final dateDemande = (demande['date'] as Timestamp?)?.toDate();
              final String patientId = demande['patientId'];
              final String idDemande = demande.id;

              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance.collection('users').doc(patientId).get(),
                builder: (context, userSnapshot) {
                  if (userSnapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (userSnapshot.hasError || !userSnapshot.hasData) {
                    return const ListTile(
                      title: Text("Erreur de chargement du patient"),
                    );
                  }

                  final patientData = userSnapshot.data!;
                  final String nomPatient = patientData['name'];

                  return Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                    margin: const EdgeInsets.only(bottom: 15),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.person,
                                  color: Color(0xFF54D3C2), size: 40),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Patient : $nomPatient",
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    if (dateDemande != null)
                                      Text(
                                        "Date : ${dateDemande.day}/${dateDemande.month}/${dateDemande.year}",
                                        style: const TextStyle(
                                            fontSize: 14, color: Colors.black54),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                         
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              ElevatedButton(
                                onPressed: () async {
                                  await _mettreAJourStatutDemande(
                                      idDemande, 'Acceptée', context, patientId);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF4CAF50),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                ),
                                child: const Text("Accepter"),
                              ),
                              const SizedBox(width: 10),
                              ElevatedButton(
                                onPressed: () async {
                                  await _mettreAJourStatutDemande(
                                      idDemande, 'Rejetée', context, patientId);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFFF44336),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                ),
                                child: const Text("Rejeter"),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }


  Future<void> _mettreAJourStatutDemande(
      String idDemande, String nouveauStatut, BuildContext context, String patientId) async {
    try {
      await FirebaseFirestore.instance
          .collection('demandes')
          .doc(idDemande)
          .update({'status': nouveauStatut});

    
      await FirebaseFirestore.instance.collection('notifications').add({
        'patientId': patientId,
        'message': "Votre demande de consultation a été $nouveauStatut.",
        'timestamp': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Demande $nouveauStatut avec succès")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Erreur : ${e.toString()}")),
      );
    }
  }
}
