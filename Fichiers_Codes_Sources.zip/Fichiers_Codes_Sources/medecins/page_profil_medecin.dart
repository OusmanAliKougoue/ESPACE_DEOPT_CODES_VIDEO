import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'page_modification_profil_medecin.dart'; 

class PageProfilMedecin extends StatelessWidget {
  const PageProfilMedecin({super.key});

  Future<Map<String, dynamic>?> _recupererInfosMedecin() async {
    try {
      final String idMedecin = FirebaseAuth.instance.currentUser!.uid;
      final DocumentSnapshot medecinSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(idMedecin)
          .get();

      if (medecinSnapshot.exists) {
        return medecinSnapshot.data() as Map<String, dynamic>;
      } else {
        return null;
      }
    } catch (e) {
      print("Erreur lors de la récupération des informations : $e");
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Profil Médecin",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: FutureBuilder<Map<String, dynamic>?>(
        future: _recupererInfosMedecin(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text("Erreur lors du chargement du profil"));
          }
          if (!snapshot.hasData || snapshot.data == null) {
            return const Center(child: Text("Aucune information disponible"));
          }

          final medecinData = snapshot.data!;
          final String nom = medecinData['name'] ?? 'Nom inconnu';
          final String specialite = medecinData['specialty'] ?? 'Non spécifiée';
          final String licence = medecinData['license'] ?? 'Non spécifiée';
          final String tel = medecinData['phone'] ?? 'Non spécifiée';
          final String sexe = medecinData['sexe'] ?? 'Non spécifiée';
          final String adresse = medecinData['address'] ?? 'Non spécifiée';
          final String age = medecinData['age'] ?? 'Non spécifiée';
           final String disponibilite = medecinData['availability'] ?? 'Non spécifiée';

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage("images/doctor_placeholder.png"),
                ),
                const SizedBox(height: 20),
                Text(
                  "Nom : Dr. $nom",
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(
                  "Âge : $age",
                  style: const TextStyle(fontSize: 18, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  "Sexe : $sexe",
                  style: const TextStyle(fontSize: 18, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  "Spécialité : $specialite",
                  style: const TextStyle(fontSize: 16, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  "Numero de Licence: $licence",
                  style: const TextStyle(fontSize: 16, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  "Adresse : $adresse",
                  style: const TextStyle(fontSize: 18, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  "Téléphone : $tel",
                  style: const TextStyle(fontSize: 16, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  "Disponibilité: $disponibilite",
                  style: const TextStyle(fontSize: 16, color: Colors.black54),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const ModifierMedecin(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF54D3C2),
                  ),
                  child: const Text("Modifier Profil"),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
