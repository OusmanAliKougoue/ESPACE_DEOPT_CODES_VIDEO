import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PageHistoriqueMessagesMedecin extends StatelessWidget {
  const PageHistoriqueMessagesMedecin({super.key});

  @override
  Widget build(BuildContext context) {
    final String idMedecin = FirebaseAuth.instance.currentUser!.uid; 

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Historique des Consultations",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('conversations')
            .where('participants', arrayContains: idMedecin) 
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text("Erreur de chargement des consultations"));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("Aucune consultation enregistrée"));
          }

          final conversations = snapshot.data!.docs;

          return ListView.builder(
            itemCount: conversations.length,
            itemBuilder: (context, index) {
              final conversation = conversations[index];
              final List<dynamic> participants = conversation['participants'];
              final String patientId = participants.firstWhere((id) => id != idMedecin);
              final Timestamp dateTimestamp = conversation['created_at'];
              final DateTime dateConsultation = dateTimestamp.toDate();

              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance.collection('users').doc(patientId).get(),
                builder: (context, userSnapshot) {
                  if (userSnapshot.connectionState == ConnectionState.waiting) {
                    return const ListTile(
                      title: Text("Chargement des informations du patient..."),
                    );
                  }
                  if (userSnapshot.hasError || !userSnapshot.hasData || !userSnapshot.data!.exists) {
                    return const ListTile(
                      title: Text("Erreur de chargement du patient"),
                      subtitle: Text("Impossible d'afficher les informations du patient."),
                    );
                  }

                  final patientData = userSnapshot.data!.data() as Map<String, dynamic>;
                  final String nomPatient = patientData['name'] ?? 'Inconnu';
                  final String emailPatient = patientData['email'] ?? 'Email non disponible';

                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    margin: const EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      leading: const Icon(Icons.person, color: Color(0xFF54D3C2)),
                      title: Text("Vous avez consulté $nomPatient"),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Email : $emailPatient"),
                          Text(
                            "Date : ${dateConsultation.day}/${dateConsultation.month}/${dateConsultation.year} à ${dateConsultation.hour}:${dateConsultation.minute}",
                            style: const TextStyle(color: Colors.black54),
                          ),
                        ],
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.info, color: Color(0xFF54D3C2)),
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                  "Détails de la consultation avec $nomPatient le ${dateConsultation.day}/${dateConsultation.month}/${dateConsultation.year}"),
                            ),
                          );
                        },
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
