import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:login_register/medecins/page_messagerie_medecin.dart';

class ListeConversationsPage extends StatelessWidget {
  final String medecinId;

  const ListeConversationsPage({super.key, required this.medecinId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Conversations",
          style: TextStyle(color: Colors.white, fontSize: 20),
          ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('conversations')
            .where('participants', arrayContains: medecinId)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("Aucune conversation disponible"));
          }

          final conversations = snapshot.data!.docs;

          return ListView.builder(
            itemCount: conversations.length,
            itemBuilder: (context, index) {
              final conversation = conversations[index];
              final List participants = conversation['participants'];
              final String patientId = participants.firstWhere(
                  (id) => id != medecinId); 

              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance
                    .collection('users')
                    .doc(patientId)
                    .get(),
                builder: (context, userSnapshot) {
                  if (userSnapshot.connectionState ==
                      ConnectionState.waiting) {
                    return const ListTile(
                      title: Text("Chargement..."),
                    );
                  }

                  if (!userSnapshot.hasData || !userSnapshot.data!.exists) {
                    return const ListTile(
                      title: Text("Patient inconnu"),
                    );
                  }

                  final userData = userSnapshot.data!;
                  final String nomPatient = userData['name'];

                  return Card(
                    margin: const EdgeInsets.symmetric(
                        vertical: 8, horizontal: 16),
                    child: ListTile(
                      leading: const CircleAvatar(
                        backgroundImage:
                            AssetImage("images/profile_placeholder.png"),
                      ),
                      title: Text(nomPatient),
                      subtitle: const Text("Appuyez pour ouvrir la conversation"),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PageMessagerieMedecin(
                              patientId: patientId,
                              conversationId: conversation.id,
                              medecinId: medecinId,
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
