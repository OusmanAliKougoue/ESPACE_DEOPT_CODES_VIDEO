
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PageNotificationMedecin extends StatelessWidget {
  const PageNotificationMedecin({super.key});

  @override
  Widget build(BuildContext context) {
    final String medecinId = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Notifications",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('notifications')
            .where('receiverId', isEqualTo: medecinId)
          
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("Aucune notification"));
          }

          final notifications = snapshot.data!.docs;

          return ListView.builder(
            itemCount: notifications.length,
            itemBuilder: (context, index) {
              final notification = notifications[index];
              final String message = notification['message'];
              final DateTime date =
                  (notification['timestamp'] as Timestamp).toDate();

              return ListTile(
                leading: const Icon(Icons.notifications, color: Color(0xFF54D3C2)),
                title: Text(message),
                subtitle: Text(
                    "Reçu le : ${date.day}/${date.month}/${date.year} à ${date.hour}:${date.minute}"),
              );
            },
          );
        },
      ),
    );
  }
}

