import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ModifierMedecin extends StatefulWidget {
  const ModifierMedecin({super.key});

  @override
  State<ModifierMedecin> createState() => _ModifierMedecinState();
}

class _ModifierMedecinState extends State<ModifierMedecin> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _sexeController = TextEditingController();
  final TextEditingController _specialtyController = TextEditingController();
  final TextEditingController _disponibleController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _recupererInfosMedecin();
  }

  Future<void> _recupererInfosMedecin() async {
    try {
      final String idMedecin = FirebaseAuth.instance.currentUser!.uid;
      final DocumentSnapshot medecinSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(idMedecin)
          .get();

      if (medecinSnapshot.exists) {
        final medecinData = medecinSnapshot.data() as Map<String, dynamic>;
        _nameController.text = medecinData['name'] ?? '';
        _ageController.text = medecinData['age'] ?? '';
        _sexeController.text = medecinData['sexe'] ?? '';
        _specialtyController.text = medecinData['specialty'] ?? '';
        _disponibleController.text = medecinData['availability'] ?? '';
        _addressController.text = medecinData['address'] ?? '';
        _phoneController.text = medecinData['phone'] ?? '';
      }
    } catch (e) {
      print("Erreur lors de la récupération des informations : $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Erreur de chargement des informations")),
      );
    }
  }

  Future<void> _modifierProfil() async {
    if (_formKey.currentState?.validate() ?? false) {
      try {
        final String idMedecin = FirebaseAuth.instance.currentUser!.uid;
        final Map<String, dynamic> updatedData = {
          'name': _nameController.text.trim(),
          'age': _ageController.text.trim(),
          'sexe': _sexeController.text.trim(),
          'specialty': _specialtyController.text.trim(),
          'availability': _disponibleController.text.trim(),
          'address': _addressController.text.trim(),
          'phone': _phoneController.text.trim(),
        };

        await FirebaseFirestore.instance
            .collection('users')
            .doc(idMedecin)
            .update(updatedData);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Profil modifié avec succès")),
        );

        Navigator.pop(context); 
      } catch (e) {
        print("Erreur lors de la modification du profil : $e");
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Erreur lors de la modification du profil")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text("Modifier Profil Médecin",
         style: TextStyle(color: Colors.white, fontSize: 20),),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Nom',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Le nom est obligatoire' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _ageController,
                decoration: const InputDecoration(
                  labelText: 'Âge',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) =>
                    value!.isEmpty ? 'L\'âge est obligatoire' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _sexeController,
                decoration: const InputDecoration(
                  labelText: 'Sexe',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'Le sexe est obligatoire' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _specialtyController,
                decoration: const InputDecoration(
                  labelText: 'Spécialité',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'La spécialité est obligatoire' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _disponibleController,
                decoration: const InputDecoration(
                  labelText: 'Disponiblité',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'L\'expérience est obligatoire' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _addressController,
                decoration: const InputDecoration(
                  labelText: 'Adresse',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value!.isEmpty ? 'L\'adresse est obligatoire' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _phoneController,
                decoration: const InputDecoration(
                  labelText: 'Téléphone',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.phone,
                validator: (value) =>
                    value!.isEmpty ? 'Le téléphone est obligatoire' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _modifierProfil,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF54D3C2),
                ),
                child: const Text("Enregistrer les modifications"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
