import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:login_register/logins/page_connexion.dart';
import 'package:login_register/medecins/listes_conversations.dart';
import 'package:login_register/medecins/page_gestion_demandes.dart';
import 'package:login_register/medecins/page_gestion_rdv.dart';
import 'package:login_register/medecins/page_hist_cons_medecin.dart';
import 'package:login_register/medecins/page_notification_medecin.dart';
import 'package:login_register/medecins/page_profil_medecin.dart';

class DoctorPage extends StatefulWidget {
  const DoctorPage({super.key});
  
  @override
  State<DoctorPage> createState() => _DoctorPageState();
}

class _DoctorPageState extends State<DoctorPage> {
  String doctorName = "Médecin"; 
    final String medecinId = FirebaseAuth.instance.currentUser!.uid;
  @override
  void initState() {
    super.initState();
    _fetchDoctorName(); 
  }

  
  Future<void> _fetchDoctorName() async {
    try {
      final userId = FirebaseAuth.instance.currentUser!.uid;
      final userDoc = await FirebaseFirestore.instance.collection('users').doc(userId).get();

      if (userDoc.exists) {
        setState(() {
          doctorName = userDoc.data()?['name'] ?? "Médecin";
        });
      }
    } catch (e) {
      print("Erreur lors de la récupération du nom : $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        elevation: 0,
        title: const Text(
          "Espace Médecin",
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
            iconTheme: const IconThemeData(
            color: Colors.white, 
         ),
        actions: [
          IconButton(
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Déconnexion réussie !")),
              );
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => PageConnexion()),
              );
            },
            icon: const Icon(Icons.logout, color: Colors.white),
          ),
        ],
      ),
      drawer: Drawer(
      
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Color(0xFF54D3C2),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircleAvatar(
                    radius: 30,
                    backgroundImage: AssetImage("images/profile_placeholder.png"),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "$doctorName",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person),
              title: const Text("Profil"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageProfilMedecin()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.schedule),
              title: const Text("Rendez-vous"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageGestionRendezVous()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.chat),
              title: const Text("Messages"),
              onTap: () {
                 Navigator.push(
                  context,
                   MaterialPageRoute(
                    builder: (context) => ListeConversationsPage(medecinId: medecinId),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.history),
              title: const Text("Historique des Consultations"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const  PageHistoriqueMessagesMedecin()),
                );
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text("Déconnexion", style: TextStyle(color: Colors.red)),
              onTap: () async {
                await FirebaseAuth.instance.signOut();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Déconnexion réussie !")),
                );
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => PageConnexion()),
                );
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          color: const Color(0xFFFFFFFF),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              _buildWelcomeSection(),
              const SizedBox(height: 30),
              _buildFeatureRow(),
              const SizedBox(height: 30),
              _buildSectionContainer("Consultations en Attente", () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageGestionDemandes()),
                );
              }),
                _buildSectionContainer("Rendez-vous Planifiés", () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const PageGestionRendezVous()),
                    );
                  }),
              
                _buildSectionContainer("Notifications ", () {
                   Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const PageNotificationMedecin()),
                    );
               }),
            _buildSectionContainer("Historique des Consultations", () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const  PageHistoriqueMessagesMedecin()),
                    );
                  }),
                ],
              ),
            ),
          ),
        );
      }
      Widget _buildWelcomeSection() {
        return Container(
          height: 200,
          width: 350,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: const Color(0xFF54D3C2),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                        "Bienvenue,\nDr. $doctorName !",
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "Echangez avec vos patients et organisez des rendez-vous.",
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
          ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: Image.asset(
              "images/docteur1.png",
              height: 150,
              width: 100,
              fit: BoxFit.cover,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildFeatureContainer(Icons.pending_actions, "Consultations", const Color.fromARGB(255, 151, 17, 171), () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ListeConversationsPage(medecinId: medecinId),),
          );
        }),
        _buildFeatureContainer(Icons.schedule, "Rendez-vous", const Color(0xFF64B5F6), () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const PageGestionDemandes ()),
          );
        }),
        _buildFeatureContainer(Icons.chat, "Messages", const Color(0xFFFFD54F), () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ListeConversationsPage(medecinId: medecinId),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildFeatureContainer(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 90,
        width: 100,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 2,
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 30),
            const SizedBox(height: 5),
            Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionContainer(String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 90,
        width: 350,
        margin: const EdgeInsets.only(bottom: 15),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: const Color(0xFF54D3C2),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade300,
              spreadRadius: 1,
              blurRadius: 5,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(Icons.info_outline, color: Colors.white, size: 28),
            const SizedBox(width: 15),
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
