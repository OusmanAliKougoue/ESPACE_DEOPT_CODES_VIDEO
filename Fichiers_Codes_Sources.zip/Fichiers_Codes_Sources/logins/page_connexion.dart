import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:login_register/logins/page_inscription.dart';
import 'package:login_register/medecins/page_medecin.dart';
import 'package:login_register/patients/page_patient.dart';

class PageConnexion extends StatefulWidget {
  @override
  _PageConnexionState createState() => _PageConnexionState();
}

class _PageConnexionState extends State<PageConnexion> {
  final _formKey = GlobalKey<FormState>();
  final emailController = TextEditingController();
  final motDePasseController = TextEditingController();
  bool cacherMotDePasse = true;

  bool isValidEmail(String email) {
    final regex = RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
    return regex.hasMatch(email);
  }

  Future<void> _resetPassword() async {
    if (emailController.text.isEmpty || !isValidEmail(emailController.text)) {
      Fluttertoast.showToast(
        msg: "Veuillez fournir une adresse e-mail valide pour réinitialiser le mot de passe.",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        backgroundColor: Colors.orange,
        textColor: Colors.white,
      );
      return;
    }

    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(
        email: emailController.text.trim(),
      );
      Fluttertoast.showToast(
        msg: "Un e-mail de réinitialisation a été envoyé à ${emailController.text}.",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        backgroundColor: Colors.green,
        textColor: Colors.white,
      );
    } catch (e) {
      Fluttertoast.showToast(
        msg: "Erreur lors de la réinitialisation : ${e.toString()}",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 150),
              const Icon(
                Icons.person_add_alt_rounded,
                size: 100,
                color: Color(0xFF54D3C2),
              ),
              const Text(
                "S'identifier",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 30),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: TextFormField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.email, color: Color(0xFF54D3C2)),
                    labelText: "Email",
                    hintText: "Donnez votre e-mail",
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Merci de fournir une adresse e-mail";
                    } else if (!isValidEmail(value)) {
                      return "Veuillez entrer un email valide";
                    }
                    return null;
                  },
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: TextFormField(
                  controller: motDePasseController,
                  obscureText: cacherMotDePasse,
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.key, color: Color(0xFF54D3C2)),
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          cacherMotDePasse = !cacherMotDePasse;
                        });
                      },
                      icon: cacherMotDePasse
                          ? const Icon(Icons.visibility_off_outlined)
                          : const Icon(Icons.visibility),
                    ),
                    hintText: "Mot de passe",
                    labelText: "Mot de passe",
                    border: const OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Le mot de passe ne peut pas être vide";
                    } else if (value.length < 8) {
                      return "Le mot de passe doit comporter au moins 8 caractères";
                    }
                    return null;
                  },
                ),
              ),

             //si mot de passe oublié on peut demander de reinitialiser
              Padding(
                padding: const EdgeInsets.only(right: 20, top: 8),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: _resetPassword,
                    child: const Text(
                      "Mot de passe oublié ?",
                      style: TextStyle(
                        color: Color(0xFF54D3C2),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 10),
                child: ElevatedButton(
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      try {
                        await FirebaseAuth.instance.signInWithEmailAndPassword(
                          email: emailController.text.trim(),
                          password: motDePasseController.text.trim(),
                        );
                        final userId = FirebaseAuth.instance.currentUser!.uid;
                        final userDoc = await FirebaseFirestore.instance
                            .collection('users')
                            .doc(userId)
                            .get();

                        if (userDoc.exists) {
                          final role = userDoc.data()?['role'];
                          print("Rôle de l'utilisateur connecté : $role");

                          // redirection vers l'espace approprié selon le role
                          if (role == 'medecin') {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const DoctorPage()),
                            );
                          } else if (role == 'patient') {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const HomePage()),
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                    "Rôle inconnu, veuillez contacter l'administrateur."),
                                behavior: SnackBarBehavior.floating,
                                backgroundColor: Colors.orange,
                              ),
                            );
                          }
                        }
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text("Erreur: ${e.toString()}"),
                            behavior: SnackBarBehavior.floating,
                            backgroundColor: Colors.red,
                          ),
                        );
                      }
                    }
                  },
                  child: const Text("Connexion"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF54D3C2),
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 5),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 10),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MyLoginPage()),
                    );
                  },
                  child: const Text("S'inscrire"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
