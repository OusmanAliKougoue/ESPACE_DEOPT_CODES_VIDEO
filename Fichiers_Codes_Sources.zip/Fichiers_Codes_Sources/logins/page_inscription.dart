import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:login_register/logins/page_connexion.dart';
import 'package:login_register/logins/page_profilUser.dart';

class MyLoginPage extends StatefulWidget {
  const MyLoginPage({super.key});

  @override
  State<MyLoginPage> createState() => _MyLoginPageState();
}

class _MyLoginPageState extends State<MyLoginPage> {
  var cacherMotDePasse = true;
  final _formKey = GlobalKey<FormState>();
  var motDePasseFieldController = TextEditingController();
  var confirmMotDePasseFieldController = TextEditingController();
  var emailFieldController = TextEditingController();

  bool isValidEmail(String email) {
    final regex = RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
    return regex.hasMatch(email);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 150),
              const Icon(Icons.person_add_alt_rounded,
                  size: 100, color: Color(0xFF54D3C2)),
              const Text(
                "S'inscrire",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 30),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: TextFormField(
                  controller: emailFieldController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.email, color: Color(0xFF54D3C2)),
                    labelText: "Email",
                    hintText: "Donnez votre e-mail",
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Merci de fournir une adresse e-mail";
                    } else if (!isValidEmail(value)) {
                      return "Veuillez entrer un email valide";
                    }
                    return null;
                  },
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: TextFormField(
                  controller: motDePasseFieldController,
                  obscureText: cacherMotDePasse,
                  decoration: InputDecoration(
                    hintText: "Mot de passe",
                    labelText: "Mot de passe",
                    border: const OutlineInputBorder(),
                    prefixIcon:
                        const Icon(Icons.key, color: Color(0xFF54D3C2)),
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          cacherMotDePasse = !cacherMotDePasse;
                        });
                      },
                      icon: cacherMotDePasse
                          ? const Icon(Icons.visibility_off_outlined)
                          : const Icon(Icons.visibility),
                    ),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Le mot de passe ne peut pas être vide";
                    } else if (value.length < 8) {
                      return "Le mot de passe doit comporter au moins 8 caractères";
                    }
                    return null;
                  },
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: TextFormField(
                  controller: confirmMotDePasseFieldController,
                  obscureText: cacherMotDePasse,
                  decoration: InputDecoration(
                    hintText: "Confirmer le mot de passe",
                    labelText: "Confirmer le mot de passe",
                    border: const OutlineInputBorder(),
                    prefixIcon:
                        const Icon(Icons.key, color: Color(0xFF54D3C2)),
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          cacherMotDePasse = !cacherMotDePasse;
                        });
                      },
                      icon: cacherMotDePasse
                          ? const Icon(Icons.visibility_off_outlined)
                          : const Icon(Icons.visibility),
                    ),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "Merci de confirmer le mot de passe";
                    } else if (value != motDePasseFieldController.text) {
                      return "Les mots de passe ne correspondent pas";
                    }
                    return null;
                  },
                ),
              ),
              const SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 50, vertical: 10),
                child: ElevatedButton(
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      try {
                        // Création de l'utilisateur avec Firebase Auth
                        final UserCredential usercred =await FirebaseAuth.instance
                                .createUserWithEmailAndPassword(
                          email: emailFieldController.text,
                          password: motDePasseFieldController.text,
                        );

                        print(
                            "Bonjour ${emailFieldController.text} : ${motDePasseFieldController.text}");

                        Fluttertoast.showToast(
                          msg: "Création du compte réussie",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.CENTER,
                          timeInSecForIosWeb: 1,
                          backgroundColor: Colors.green,
                          textColor: Colors.white,
                          fontSize: 16.0,
                        );

                        // redirection vers la page profilUser apres creation
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const PageProfiluser()),
                        );
                      } catch (e) {
                        print(e);
                        Fluttertoast.showToast(
                          msg: "Erreur de création du compte : ${e.toString()}",
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.CENTER,
                          timeInSecForIosWeb: 1,
                          backgroundColor: Colors.red,
                          textColor: Colors.white,
                          fontSize: 16.0,
                        );
                      }
                    } else {
                      Fluttertoast.showToast(
                        msg: "Veuillez remplir tous les champs correctement",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.CENTER,
                        timeInSecForIosWeb: 1,
                        backgroundColor: Colors.red,
                        textColor: Colors.white,
                        fontSize: 16.0,
                      );
                    }
                  },
                  child: const Text("S'enregistrer"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF54D3C2),
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 50, vertical: 10),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => PageConnexion()),
                    );
                  },
                  child: const Text("Connexion"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
