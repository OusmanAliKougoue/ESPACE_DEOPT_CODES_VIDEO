import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:login_register/logins/page_connexion.dart';

class PageProfiluser extends StatefulWidget {
  const PageProfiluser({super.key});

  @override
  State<PageProfiluser> createState() => _PageProfiluserState();
}

class _PageProfiluserState extends State<PageProfiluser> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController specialtyController = TextEditingController();
  final TextEditingController licenseController = TextEditingController();
  final TextEditingController availabilityController = TextEditingController();
  String sexe = "Homme"; // par defaut
  String role = "patient"; // par defaut

  @override
  void initState() {
    super.initState();
    _preRemplirEmail();
  }

 
  void _preRemplirEmail() {
    final User? utilisateur = FirebaseAuth.instance.currentUser;
    if (utilisateur != null) {
      emailController.text = utilisateur.email ?? '';
    }
  }

  String? validateField(String? value, String errorMessage) {
    if (value == null || value.isEmpty) {
      return errorMessage;
    }
    return null;
  }

  void submitForm() async {
    if (_formKey.currentState?.validate() ?? false) {
      String name = nameController.text.trim();
      String email = emailController.text.trim();
      String age = ageController.text.trim();
      String address = addressController.text.trim();
      String phone = phoneController.text.trim();

      //informations communes pour les utilisateurs 
      Map<String, dynamic> userData = {
        'name': name,
        'email': email,
        'age': age,
        'address': address,
        'phone': phone,
        'sexe': sexe,
        'role': role,
        'profileComplete': true,
        'created_at': FieldValue.serverTimestamp(),
      };
       //informations specifiques pour les medecins
       if (role == "medecin") {
        String specialty = specialtyController.text.trim();
        String license = licenseController.text.trim();
        String availability = availabilityController.text.trim();

        userData.addAll({
          'specialty': specialty,
          'license': license,
          'availability': availability,
        });
      }

      try {
      
        await FirebaseFirestore.instance
            .collection('users')
            .doc(FirebaseAuth.instance.currentUser?.uid)
            .set(userData);

        Fluttertoast.showToast(msg: "Informations enregistrées avec succès !");
        print("Utilisateur ajouté : $userData");
        
        nameController.clear();
        emailController.clear();
        ageController.clear();
        addressController.clear();
        phoneController.clear();

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => PageConnexion()),
        );
      } catch (e) {
        Fluttertoast.showToast(msg: "Erreur : ${e.toString()}");
        print("Erreur lors de l'ajout de l'utilisateur : $e");
      }
    } else {
      print('Le formulaire est invalide');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          'Profil Utilisateur',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.only(top: 50),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: 'Prénom et Nom',
                      labelStyle: TextStyle(color: Color(0xFF54D3C2)),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                        validateField(value, 'Le nom est obligatoire'),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: emailController,
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      labelStyle: TextStyle(color: Color(0xFF54D3C2)),
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) =>
                        validateField(value, 'L\'email est obligatoire'),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: ageController,
                    decoration: const InputDecoration(
                      labelText: 'Âge',
                      labelStyle: TextStyle(color: Color(0xFF54D3C2)),
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) =>
                        validateField(value, 'L\'âge est obligatoire'),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: addressController,
                    decoration: const InputDecoration(
                      labelText: 'Adresse',
                      labelStyle: TextStyle(color: Color(0xFF54D3C2)),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                        validateField(value, 'L\'adresse est obligatoire'),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: phoneController,
                    decoration: const InputDecoration(
                      labelText: 'Téléphone',
                      labelStyle: TextStyle(color: Color(0xFF54D3C2)),
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.phone,
                    validator: (value) =>
                        validateField(value, 'Le téléphone est obligatoire'),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: sexe,
                    items: const [
                      DropdownMenuItem(
                        value: "Homme",
                        child: Text("Homme"),
                      ),
                      DropdownMenuItem(
                        value: "Femme",
                        child: Text("Femme"),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        sexe = value!;
                      });
                    },
                    decoration: const InputDecoration(
                      labelText: 'Sexe',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                
                  DropdownButtonFormField<String>(
                    value: role,
                    items: const [
                      DropdownMenuItem(
                        value: "patient",
                        child: Text("Patient"),
                      ),
                      DropdownMenuItem(
                        value: "medecin",
                        child: Text("Médecin"),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        role = value!;
                      });
                    },
                    decoration: const InputDecoration(
                      labelText: 'Rôle',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (role == "medecin") ...[
                    TextFormField(
                      controller: specialtyController,
                      decoration: const InputDecoration(
                        labelText: 'Spécialité',
                        labelStyle: TextStyle(color: Color(0xFF54D3C2)),
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) => validateField(
                          value, 'La spécialité est obligatoire'),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: licenseController,
                      decoration: const InputDecoration(
                        labelText: 'Numéro de licence',
                        labelStyle: TextStyle(color: Color(0xFF54D3C2)),
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) => validateField(
                          value, 'Le numéro de licence est obligatoire'),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: availabilityController,
                      decoration: const InputDecoration(
                        labelText: 'Disponibilités',
                        labelStyle: TextStyle(color: Color(0xFF54D3C2)),
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) => validateField(
                          value, 'Les disponibilités sont obligatoires'),
                    ),
                    const SizedBox(height: 16),
                  ],
                  ElevatedButton(
                    onPressed: submitForm,
                    child: const Text(
                      'Soumettre',
                      style: TextStyle(color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF54D3C2),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

