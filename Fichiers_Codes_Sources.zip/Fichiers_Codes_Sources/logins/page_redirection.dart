import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:login_register/logins/page_connexion.dart';
import 'package:login_register/logins/page_profilUser.dart';
import 'package:login_register/medecins/page_medecin.dart';
import 'package:login_register/patients/page_patient.dart';

class Dispatcher extends StatefulWidget {
  @override
  State<Dispatcher> createState() => _DispatcherState();
}

class _DispatcherState extends State<Dispatcher> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
       
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (!snapshot.hasData || snapshot.data == null) {
          return PageConnexion();
        }
        final user = snapshot.data;

        return FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance
              .collection('users')
              .doc(user!.uid)
              .get(),
          builder: (context, userSnapshot) { 
            if (userSnapshot.connectionState == ConnectionState.waiting) {
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            }

            if (userSnapshot.hasError || !userSnapshot.hasData || !userSnapshot.data!.exists) {
              return PageConnexion();
            }

            final userData = userSnapshot.data!.data() as Map<String, dynamic>;

            // on verifie  si le profil est complet pour redirger vers la page concerne
            final bool isProfileComplete = userData['profileComplete'] ?? false;
            final String role = userData['role'] ?? 'patient';

            if (!isProfileComplete) {
              // Si le profil n'est pas complet, redirige vers la page de profil User
              return const PageProfiluser();
            }

            // le role va permettre d'envoyer chaque utilisateur vers son espace propre
            if (role == 'medecin') {
              return const DoctorPage();
            } else {
              return const HomePage();
            }
          },
        );
      },
    );
  }
}
