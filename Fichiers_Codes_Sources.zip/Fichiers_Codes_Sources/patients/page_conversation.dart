import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PageConversation extends StatefulWidget {
  final String conversationId;
  final String patientId;
  final String medecinId;

  const PageConversation({
    super.key,
    required this.conversationId,
    required this.patientId,
    required this.medecinId,
  });

  @override
  State<PageConversation> createState() => _PageConversationState();
}

class _PageConversationState extends State<PageConversation> {
  final TextEditingController _messageController = TextEditingController();

    String _nomMedecin =""; 

    @override
    void initState() {
      super.initState();
      _recupererNomMedecin();
    }
  //nous allons recuperé le nom du medecin avec qui le patient ecrit pour l'affichier sur l'appBar
  Future<void> _recupererNomMedecin() async {
    try {
      final DocumentSnapshot medecinSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.medecinId)
          .get();

      if (medecinSnapshot.exists) {
        setState(() {
          _nomMedecin = medecinSnapshot['name'] ?? "Inconnu";
        });
      } else {
        setState(() {
         _nomMedecin ="Inconnu";
        });
      }
    } catch (e) {
      print("Erreur lors de la récupération du nom du medecin : $e");
      setState(() {
        _nomMedecin ="Erreur";
      });
    }
  }
 
  Future<void> _sendMessage() async {
    if (_messageController.text.trim().isEmpty) return;

    final message = {
      'senderId': widget.patientId,
      'receiverId': widget.medecinId,
      'content': _messageController.text.trim(),
      'timestamp': FieldValue.serverTimestamp(),
    };

    await FirebaseFirestore.instance
        .collection('conversations')
        .doc(widget.conversationId)
        .collection('messages')
        .add(message);

    _messageController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: Text("À : Dr $_nomMedecin",
         style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
        
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('conversations')
                  .doc(widget.conversationId)
                  .collection('messages')
                  .orderBy('timestamp', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Center(child: Text("Aucun message"));
                }

                final messages = snapshot.data!.docs;

                return ListView.builder(
                  reverse: true,
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index];
                    final isMe = message['senderId'] == widget.patientId;

                    return Align(
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(
                            vertical: 5, horizontal: 10),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: isMe ? Colors.blue : Colors.grey[300],
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          message['content'],
                          style: TextStyle(
                            color: isMe ? Colors.white : Colors.black,
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),

         
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: InputDecoration(
                      hintText: "Tapez votre message...",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                IconButton(
                  icon: const Icon(Icons.send, color: Color(0xFF54D3C2)),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
