import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PageListeMedecins extends StatefulWidget {
  const PageListeMedecins({super.key});

  @override
  State<PageListeMedecins> createState() => _PageListeMedecinsState();
}

class _PageListeMedecinsState extends State<PageListeMedecins> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Liste des Médecins",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
         
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: "Rechercher un médecin...",
                prefixIcon: const Icon(Icons.search, color: Color(0xFF54D3C2)),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: const BorderSide(color: Color(0xFF54D3C2)),
                ),
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value.trim().toLowerCase();
                });
              },
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .where('role', isEqualTo: 'medecin')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return const Center(
                    child: Text("Erreur lors du chargement des médecins"),
                  );
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Center(child: Text("Aucun médecin disponible"));
                }

                final medecins = snapshot.data!.docs.where((doc) {
                  final String name = doc['name']?.toLowerCase() ?? '';
                  return name.contains(_searchQuery);
                }).toList();

                if (medecins.isEmpty) {
                  return const Center(child: Text("Aucun médecin trouvé"));
                }

                return ListView.builder(
                  itemCount: medecins.length,
                  itemBuilder: (context, index) {
                    final medecin = medecins[index];
                    final String nom = medecin['name'] ?? 'Inconnu';
                    final String specialite = medecin['specialty'] ?? 'Non spécifiée';
                    final String telephone = medecin['phone'] ?? 'Non renseigné';

                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundImage: AssetImage("images/doctor_placeholder.png"),
                        ),
                        title: Text(
                          nom,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Spécialité : $specialite"),
                            Text("Téléphone : $telephone"),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
