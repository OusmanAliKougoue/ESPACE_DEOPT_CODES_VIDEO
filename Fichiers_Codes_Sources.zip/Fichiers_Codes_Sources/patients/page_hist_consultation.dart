import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PageHistoriqueConsultations extends StatelessWidget {
  const PageHistoriqueConsultations({super.key});

  @override
  Widget build(BuildContext context) {
    final String patientId = FirebaseAuth.instance.currentUser!.uid; 
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Historique des Consultations",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('appointments')
            .where('patientId', isEqualTo: patientId)
            .where('status', isEqualTo: 'Acceptée') 
            .orderBy('dateTime', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("Aucune consultation enregistrée"));
          }

          final appointments = snapshot.data!.docs;

          return ListView.builder(
            itemCount: appointments.length,
            itemBuilder: (context, index) {
              final appointment = appointments[index].data() as Map<String, dynamic>;
              final DateTime dateTime = (appointment['dateTime'] as Timestamp).toDate();
              final String medecinId = appointment['medecinId'];

              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance.collection('users').doc(medecinId).get(),
                builder: (context, medecinSnapshot) {
                  if (medecinSnapshot.connectionState == ConnectionState.waiting) {
                    return const ListTile(
                      title: Text("Chargement des informations du médecin..."),
                    );
                  }
                  if (medecinSnapshot.hasError || !medecinSnapshot.hasData || !medecinSnapshot.data!.exists) {
                    return const ListTile(
                      title: Text("Erreur de chargement du médecin"),
                      subtitle: Text("Impossible d'afficher les informations du médecin."),
                    );
                  }

                  final medecinData = medecinSnapshot.data!.data() as Map<String, dynamic>;
                  final String nomMedecin = medecinData['name'] ?? 'Inconnu';

                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    margin: const EdgeInsets.only(bottom: 15),
                    child: ListTile(
                      leading: const Icon(Icons.history, color: Color(0xFF54D3C2)),
                      title: Text(
                        "Vous avez consulté : Dr. $nomMedecin",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        "Date : ${dateTime.day}/${dateTime.month}/${dateTime.year} à ${dateTime.hour}:${dateTime.minute}",
                        style: const TextStyle(fontSize: 14, color: Colors.black54),
                      ),
                      trailing: ElevatedButton(
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                  "Afficher les détails pour la consultation du ${dateTime.day}/${dateTime.month}/${dateTime.year}"),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF54D3C2),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        child: const Text("Détails"),
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
