import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PageNotifications extends StatelessWidget {
  const PageNotifications({super.key});

  @override
  Widget build(BuildContext context) {
    final String userId = FirebaseAuth.instance.currentUser!.uid; 

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Notifications",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('demandes')
            .where('patientId', isEqualTo: userId) 
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("Aucune notification reçue"));
          }

          final demandes = snapshot.data!.docs;

          return ListView.builder(
            itemCount: demandes.length,
            itemBuilder: (context, index) {
              final demande = demandes[index];
              final String statut = demande['status'] ?? 'Indisponible';
              final String motif = demande['motif'] ?? '';
              final Timestamp? dateTimestamp = demande['date'] as Timestamp?;
              final DateTime? dateDemande = dateTimestamp?.toDate();

              String detailNotification;
              IconData iconNotification;
              Color iconColor;

              if (statut == 'Acceptée') {
                detailNotification = 'Votre demande de rendez-vous a été acceptée.';
                iconNotification = Icons.check_circle;
                iconColor = Colors.green;
              } else if (statut == 'Rejetée') {
                detailNotification = 'Votre demande de rendez-vous a été rejetée.';
                iconNotification = Icons.cancel;
                iconColor = Colors.red;
              } else {
                detailNotification = 'Votre demande de rendez-vous est en attente.';
                iconNotification = Icons.hourglass_top;
                iconColor = Colors.orange;
              }

              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: ListTile(
                  leading: Icon(
                    iconNotification,
                    color: iconColor,
                  ),
                  title: Text(
                    "Demande de rendez-vous",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(detailNotification),
                      if (motif.isNotEmpty) Text("Motif : $motif"),
                      if (dateDemande != null)
                        Text(
                          "Date : ${dateDemande.day}/${dateDemande.month}/${dateDemande.year}",
                          style: const TextStyle(color: Colors.black54),
                        ),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.check, color: Colors.grey),
                    onPressed: () async {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Notification marquée comme lue")),
                      );
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
