import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class PageRdvAcceptes extends StatelessWidget {
  const PageRdvAcceptes({super.key});

  @override
  Widget build(BuildContext context) {
    final String patientId = FirebaseAuth.instance.currentUser!.uid; 

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Rendez-vous Acceptés",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('demandes')
            .where('patientId', isEqualTo: patientId)
            .where('status', isEqualTo: 'Acceptée')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("Aucun rendez-vous accepté"));
          }

          final demandes = snapshot.data!.docs;

          return ListView.builder(
            itemCount: demandes.length,
            itemBuilder: (context, index) {
              final demande = demandes[index].data() as Map<String, dynamic>;
              final String medecinId = demande['medecinId'];
              final Timestamp? dateTimestamp = demande['date'] as Timestamp?;
              final DateTime? dateRdv = dateTimestamp?.toDate();
              final String motif = demande['motif'] ?? 'Aucun motif spécifié';

              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance.collection('users').doc(medecinId).get(),
                builder: (context, userSnapshot) {
                  if (userSnapshot.connectionState == ConnectionState.waiting) {
                    return const ListTile(
                      title: Text("Chargement des informations du médecin..."),
                    );
                  }
                  if (userSnapshot.hasError || !userSnapshot.hasData || !userSnapshot.data!.exists) {
                    return const ListTile(
                      title: Text("Erreur de chargement du médecin"),
                      subtitle: Text("Impossible d'afficher les informations du médecin."),
                    );
                  }

                  final medecinData = userSnapshot.data!.data() as Map<String, dynamic>;
                  final String nomMedecin = medecinData['name'] ?? 'Inconnu';
                  final String specialite = medecinData['specialty'] ?? 'Non spécifiée';
                  final String telephone = medecinData['phone'] ?? 'Non renseigné';

                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    margin: const EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      leading: const Icon(Icons.calendar_today, color: Color(0xFF54D3C2)),
                      title: Text("Médecin : $nomMedecin"),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Spécialité : $specialite"),
                          if (dateRdv != null)
                            Text(
                              "Date : ${dateRdv.day}/${dateRdv.month}/${dateRdv.year} - ${dateRdv.hour}:${dateRdv.minute}",
                            ),
                          Text("Motif : $motif"),
                          Text("Téléphone : $telephone"),
                        ],
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.phone, color: Color(0xFF64B5F6)),
                        onPressed: () {
                        
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text("Appel au médecin $nomMedecin..."),
                            ),
                          );
                        },
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
