import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:login_register/patients/page_conversation.dart';

class PageMessages extends StatelessWidget {
  const PageMessages({super.key});

  @override
  Widget build(BuildContext context) {
    final String patientId = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Messages",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('conversations')
            .where('participants', arrayContains: patientId)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("Aucune conversation"));
          }

          final conversations = snapshot.data!.docs;

          return ListView.builder(
            itemCount: conversations.length,
            itemBuilder: (context, index) {
              final conversation = conversations[index];
              final medecinId = conversation['participants']
                  .firstWhere((id) => id != patientId);

              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance.collection('users').doc(medecinId).get(),
                builder: (context, userSnapshot) {
                  if (userSnapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (userSnapshot.hasError || !userSnapshot.hasData || !userSnapshot.data!.exists) {
                    return const ListTile(
                      title: Text("Erreur de chargement du médecin"),
                    );
                  }

                  final medecinData = userSnapshot.data!.data() as Map<String, dynamic>;
                  final String nomMedecin = medecinData['name'] ?? 'Médecin inconnu';

                  return Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                    child: ListTile(
                      leading: const CircleAvatar(
                        backgroundImage: AssetImage("images/doctor_placeholder.png"),
                      ),
                      title: Text(nomMedecin), 
                      subtitle: const Text("Dernier message reçu..."),
                      trailing: const Icon(Icons.arrow_forward, color: Color(0xFF54D3C2)),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PageConversation(
                              conversationId: conversation.id,
                              patientId: patientId,
                              medecinId: medecinId,
                            ),
                          ),
                        );
                      },
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
