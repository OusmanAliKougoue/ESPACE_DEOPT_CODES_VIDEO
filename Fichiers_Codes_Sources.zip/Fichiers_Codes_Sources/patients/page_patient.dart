import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:login_register/logins/page_connexion.dart';
import 'package:login_register/patients/page_consultation.dart';
import 'package:login_register/patients/page_hist_consultation.dart';
import 'package:login_register/patients/page_liste_medecins.dart';
import 'package:login_register/patients/page_messages.dart';
import 'package:login_register/patients/page_notification.dart';
import 'package:login_register/patients/page_prochain_rdv.dart';
import 'package:login_register/patients/page_profil_patient.dart';
import 'package:login_register/patients/page_rdv.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String userName = "Utilisateur"; 

  @override
  void initState() {
    super.initState();
    _fetchUserName(); 
  }
  
  Future<void> _fetchUserName() async {
    try {
      final userId = FirebaseAuth.instance.currentUser!.uid;
      final userDoc = await FirebaseFirestore.instance.collection('users').doc(userId).get();

      if (userDoc.exists) {
        setState(() {
          userName = userDoc.data()?['name'] ?? "Utilisateur";
        });
      }
    } catch (e) {
      print("Erreur lors de la récupération du nom : $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        elevation: 4,
        title: const Text(
          "Accueil",
          style: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
         iconTheme: const IconThemeData(
            color: Colors.white, 
         ),
        actions: [
          IconButton(
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Déconnexion réussie !")),
              );
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => PageConnexion()),
              );
            },
            icon: const Icon(Icons.logout, color: Colors.white),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Color(0xFF54D3C2),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircleAvatar(
                    radius: 30,
                    backgroundImage: AssetImage("images/profile_placeholder.png"),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "$userName",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person),
              title: const Text("Profil"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageProfilPatient()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.calendar_today),
              title: const Text("Rendez-vous"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageRdv()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.history),
              title: const Text("Historique des Consultations"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageHistoriqueConsultations()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.notifications),
              title: const Text("Notifications"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageNotifications()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.message),
              title: const Text("Messages"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageMessages()),
                );
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text("Déconnexion", style: TextStyle(color: Colors.red)),
              onTap: () async {
                await FirebaseAuth.instance.signOut();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Déconnexion réussie !")),
                );
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => PageConnexion()),
                );
              },
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          color: Colors.white,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              _buildWelcomeSection(),
              const SizedBox(height: 30),
              _buildFeatureRow(),
              const SizedBox(height: 30),
              _buildSectionContainer("Votre Prochain Rendez-vous", () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageRdvAcceptes()),
                );
              }),
              _buildSectionContainer("Historique des Consultations", () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageHistoriqueConsultations()),
                );
              }),
              _buildSectionContainer("Notifications", () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageNotifications()),
                );
              }),
              _buildSectionContainer("Médecins Disponibles", () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const PageListeMedecins()),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWelcomeSection() {
    return Container(
      height: 200,
      width: 350,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: const Color(0xFF54D3C2),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Bienvenue,\n$userName",
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  "Consultez vos médecins \nrapidement et echangez vos besoins.",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
          ),
          ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: Image.asset(
              "images/docteur1.png",
              height: 150,
              width: 100,
              fit: BoxFit.cover,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureRow() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildFeatureContainer(Icons.assignment, "Consulter",const Color.fromARGB(255, 151, 17, 171), () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const PageMedecinsDisponibles()),
          );
        }),
        _buildFeatureContainer(Icons.date_range, "Rendez-vous", const Color(0xFF64B5F6), () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const PageRdv()),
          );
        }),
        _buildFeatureContainer(Icons.message, "Messages", const Color(0xFFFFD54F), () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const PageMessages()),
          );
        }),
      ],
    );
  }

  Widget _buildFeatureContainer(IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 80,
        width: 100,
        margin: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(15),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 2,
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 30),
            const SizedBox(height: 5),
            Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionContainer(String title, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 90,
        width: 350,
        margin: const EdgeInsets.only(bottom: 15),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: const Color(0xFF54D3C2),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.shade300,
              spreadRadius: 1,
              blurRadius: 5,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(Icons.info_outline, color: Colors.white, size: 28),
            const SizedBox(width: 15),
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
