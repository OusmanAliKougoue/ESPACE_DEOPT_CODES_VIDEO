
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class PageRdv extends StatefulWidget {
  const PageRdv({super.key});

  @override
  State<PageRdv> createState() => _PageRdvState();
}

class _PageRdvState extends State<PageRdv> {
  final _formKey = GlobalKey<FormState>();
  final _dateController = TextEditingController();
  final _motifController = TextEditingController();
  String? _selectedMedecinId;

  @override
  void dispose() {
    _dateController.dispose();
    _motifController.dispose();
    super.dispose();
  }

  Future<void> _envoyerDemande() async {
    if (_formKey.currentState!.validate()) {
      final String patientId = FirebaseAuth.instance.currentUser!.uid;
      final String motif = _motifController.text.trim();
      final DateTime date = DateTime.parse(_dateController.text.trim());

      try {
        await FirebaseFirestore.instance.collection('demandes').add({
          'patientId': patientId,
          'medecinId': _selectedMedecinId,
          'motif': motif,
          'date': date,
          'status': 'En attente',
          'created_at': FieldValue.serverTimestamp(),
        });

        Fluttertoast.showToast(msg: "Demande de rendez-vous envoyée avec succès !");
        Navigator.pop(context);
      } catch (e) {
        Fluttertoast.showToast(msg: "Erreur : ${e.toString()}");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text("Demande de Rendez-vous",
         style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('users').where('role', isEqualTo: 'medecin').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const CircularProgressIndicator();
                  }
                  if (snapshot.hasError || !snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Text("Aucun médecin disponible");
                  }

                  final medecins = snapshot.data!.docs;
                  return DropdownButtonFormField<String>(
                    value: _selectedMedecinId,
                    items: medecins.map((doc) {
                      return DropdownMenuItem(
                        value: doc.id,
                        child: Text(doc['name']),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedMedecinId = value;
                      });
                    },
                    decoration: const InputDecoration(
                      labelText: 'Sélectionnez un médecin',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) => value == null ? 'Veuillez sélectionner un médecin' : null,
                  );
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _dateController,
                decoration: const InputDecoration(
                  labelText: 'Date du rendez-vous',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.datetime,
                validator: (value) => value == null || value.isEmpty ? 'Veuillez entrer une date' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _motifController,
                decoration: const InputDecoration(
                  labelText: 'Motif du rendez-vous',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.isEmpty ? 'Veuillez entrer un motif' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _envoyerDemande,
                child: const Text("Envoyer la demande"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


