import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:login_register/patients/page_conversation.dart';

class PageMedecinsDisponibles extends StatelessWidget {
  const PageMedecinsDisponibles({super.key});

  @override
  Widget build(BuildContext context) {
    final String patientId = FirebaseAuth.instance.currentUser!.uid; 

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text("Médecins Disponibles",
         style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('users')
            .where(FieldPath.fromString('role'), isEqualTo: 'medecin')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            print("Erreur lors de la récupération des données : ${snapshot.error}");
            return const Center(
              child: Text("Erreur lors du chargement des médecins"),
            );
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            print("Aucun médecin trouvé dans la base de données");
            return const Center(child: Text("Aucun médecin disponible"));
          }

          final medecins = snapshot.data!.docs;
          print("Nombre de médecins disponibles : ${medecins.length}");

          return ListView.builder(
            itemCount: medecins.length,
            itemBuilder: (context, index) {
              final medecin = medecins[index];

              return Card(
                margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: ListTile(
                  leading: const CircleAvatar(
                    backgroundImage: AssetImage("images/doctor_placeholder.png"),
                  ),
                  title: Text(
                    medecin['name'],
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text("Spécialité : ${medecin['specialty']}"),
                  trailing: ElevatedButton(
                    onPressed: () async {
                      final String medecinId = medecin.id; 

                      
                      final String conversationId = await _getOrCreateConversation(
                        patientId,
                        medecinId,
                      );

                     
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PageConversation(
                            patientId: patientId,
                            conversationId: conversationId,
                            medecinId: medecinId,
                          ),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF54D3C2),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text("Consulter"),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  // cette fonction va nous permettre de creer ou recupereer une conversation
  Future<String> _getOrCreateConversation(String patientId, String medecinId) async {
    final conversationRef = FirebaseFirestore.instance.collection('conversations');

    // conversation existante
    final querySnapshot = await conversationRef
        .where('participants', arrayContains: patientId)
        .get();

    for (var doc in querySnapshot.docs) {
      final participants = doc['participants'] as List<dynamic>;
      if (participants.contains(medecinId)) {
        print("Conversation existante trouvée : ${doc.id}");
        return doc.id; 
      }
    }

    // créer une nouvelle
    final newConversationRef = conversationRef.doc();
    await newConversationRef.set({
      'participants': [patientId, medecinId],
      'created_at': FieldValue.serverTimestamp(),
    });
    print("Nouvelle conversation créée : ${newConversationRef.id}");
    return newConversationRef.id;
  }
}
