import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'page_modification_profil_patient.dart'; 

class PageProfilPatient extends StatelessWidget {
  const PageProfilPatient({super.key});

  Future<Map<String, dynamic>?> _recupererInfosPatient() async {
    try {
      final String idPatient = FirebaseAuth.instance.currentUser!.uid;
      final DocumentSnapshot patientSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(idPatient)
          .get();

      if (patientSnapshot.exists) {
        return patientSnapshot.data() as Map<String, dynamic>;
      } else {
        return null;
      }
    } catch (e) {
      print("Erreur lors de la récupération des informations : $e");
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF54D3C2),
        title: const Text(
          "Profil Patient",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: FutureBuilder<Map<String, dynamic>?>(
        future: _recupererInfosPatient(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return const Center(child: Text("Erreur lors du chargement du profil"));
          }
          if (!snapshot.hasData || snapshot.data == null) {
            return const Center(child: Text("Aucune information disponible"));
          }

          final patientData = snapshot.data!;
          final String nom = patientData['name'] ?? 'Nom inconnu';
          final String adresse = patientData['address'] ?? 'Non spécifiée';
          final String age = patientData['age'] ?? 'Non spécifié';
          final String tel = patientData['phone'] ?? 'Non spécifiée';
          final String sexe = patientData['sexe'] ?? 'Non spécifié';

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage("images/patient_placeholder.png"),
                ),
                const SizedBox(height: 20),
                Text(
                  "Nom : $nom",
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(
                  "Âge : $age ans",
                  style: const TextStyle(fontSize: 16, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  "Sexe : $sexe",
                  style: const TextStyle(fontSize: 16, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  "Téléphone : $tel",
                  style: const TextStyle(fontSize: 16, color: Colors.black54),
                ),
                const SizedBox(height: 10),
                Text(
                  "Adresse : $adresse",
                  style: const TextStyle(fontSize: 16, color: Colors.black54),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const ModifierPatient(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF54D3C2),
                  ),
                  child: const Text("Modifier Profil"),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
